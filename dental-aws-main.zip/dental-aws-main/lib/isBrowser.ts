export const isBrowser: boolean = (process as any).browser;
