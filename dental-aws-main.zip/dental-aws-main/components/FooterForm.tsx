import React from "react";
import styled from "styled-components";

const FooterForm = styled("h5")`
`;

export default function FooterFormComponent() {
    return (
        <FooterForm>
            all rights reserved
        </FooterForm>
    )
}
