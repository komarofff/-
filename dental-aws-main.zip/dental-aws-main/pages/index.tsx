import * as React from "react";
import Search from "./search";


const IndexPage: React.FunctionComponent = () => {
  return (
    <Search />
  );
};

export default IndexPage;
