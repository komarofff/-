import styled from "styled-components";

export const h2 = styled("div")`{
  
}
`;